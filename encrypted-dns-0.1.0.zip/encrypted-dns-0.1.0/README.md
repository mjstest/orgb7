# encrypted-dns-configs
Configuration profiles for DNS HTTPS and DNS over TLS
